<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PersonClientController extends Controller
{
    //
}
